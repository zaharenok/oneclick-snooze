// Service worker for handling alarm events and tab restoration

importScripts('alarmManager.js', '../lib/messages.js');

// Cached localized messages for the desktop notification (stored choice > browser locale).
let _bgMessages = null;
async function bgMessages() {
  if (_bgMessages) return _bgMessages;
  const stored = await new Promise((resolve) => {
    chrome.storage.local.get('locale', (res) => resolve(res.locale));
  });
  const ui = (chrome.i18n && chrome.i18n.getUILanguage) ? chrome.i18n.getUILanguage() : MESSAGES_DEFAULT;
  _bgMessages = await messagesLoad(messagesResolveLocale(ui, stored));
  return _bgMessages;
}

// ── Restore overdue tabs (used by onStartup, periodic catch-up, and alarms) ──
// Mutex prevents concurrent restores (onStartup + catchup alarm + individual alarms)
// RESTORE_GAP_MS must match RESTORE_QUEUE_GAP_MS in lib/queueStagger.js
const RESTORE_GAP_MS = 5000;
let _restoreLock = false;

async function restoreOverdueTabs(options = {}) {
  const notify = options.notify === true;
  if (_restoreLock) return;
  _restoreLock = true;
  try {
    for (;;) {
      const { snoozedTabs = [] } = await chrome.storage.local.get('snoozedTabs');
      const due = AlarmManager.selectNextDueTab(snoozedTabs, Date.now());
      if (!due) break;

      // Mark expired BEFORE opening — persisted, survives SW crash; next catch-up retries the rest
      const updated = snoozedTabs.map(t =>
        t.id === due.id ? { ...t, status: 'expired', completedAt: Date.now() } : t
      );
      await chrome.storage.local.set({ snoozedTabs: updated });

      try {
        await chrome.tabs.create({ url: due.url });

        if (notify) {
          chrome.runtime.sendMessage({
            type: 'tabRestored',
            tabId: due.id
          }).catch(() => {});

          const msgs = await bgMessages();
          chrome.notifications.create({
            type: 'basic',
            iconUrl: '../icons/icon48.png',
            title: msgs.extName || 'OneClick Snooze',
            message: messagesSub(msgs.notif_restored, due.title)
          }, () => void chrome.runtime.lastError);
        }
        playRestoreSound();
      } catch (e) {
        console.warn('Failed to restore tab:', due.id, e);
      }

      // Queue: simultaneous alarms (e.g. «Tomorrow 09:00») open tabs one by one
      if (AlarmManager.countDueTabs(snoozedTabs, Date.now(), due.id) > 0) {
        await new Promise(r => setTimeout(r, RESTORE_GAP_MS));
      }
    }
  } finally {
    _restoreLock = false;
  }
}

// ── Alarm handler ──
chrome.alarms.onAlarm.addListener(async (alarm) => {
  // Periodic catch-up + individual snooze alarms both drain due tabs as a spaced queue
  if (alarm.name === 'catchup' || alarm.name.startsWith('snooze_')) {
    await restoreOverdueTabs({ notify: alarm.name.startsWith('snooze_') });
  }
});

// ── Offscreen audio ──
let creatingOffscreen;
async function playRestoreSound() {
  try {
    const { settings } = await chrome.storage.local.get('settings');
    if (settings && settings.soundEnabled === false) {
      return;
    }

    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT']
    });

    if (contexts.length === 0) {
      creatingOffscreen = creatingOffscreen || chrome.offscreen.createDocument({
        url: 'offscreen/offscreen.html',
        reasons: ['AUDIO_PLAYBACK'],
        justification: 'Play a sound when a snoozed tab is restored'
      });
      await creatingOffscreen.catch(() => {});
      creatingOffscreen = null;
    }

    // sendMessage now waits for sendResponse from offscreen listener
    await chrome.runtime.sendMessage({ type: 'play-sound' }).catch(e => {
      console.warn('play-sound message failed:', e);
    });

    setTimeout(() => {
      chrome.offscreen.closeDocument().catch(() => {});
    }, 3000);
  } catch (e) {
    console.warn('Could not play restore sound:', e);
  }
}

// ── Lifecycle ──
function ensureCatchupAlarm() {
  chrome.alarms.create('catchup', { periodInMinutes: 5 });
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('OneClick Snooze installed');
  ensureCatchupAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  ensureCatchupAlarm();
  restoreOverdueTabs();
});
